/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HILARY ORELLANA
 */
public class AlertaStock {
    public static void generarAlerta(Producto producto) {
        if (producto.getStock() < 10) {
            System.out.println("¡Alerta! Stock bajo para el producto: " + producto.getNombre());
        }
    }

    
}
