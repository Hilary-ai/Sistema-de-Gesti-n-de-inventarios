/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HILARY ORELLANA
 */
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Inventario inventario = new Inventario();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\nSistema de Gestión de Inventarios");
            System.out.println("1. Agregar producto");
            System.out.println("2. Eliminar producto");
            System.out.println("3. Buscar producto");
            System.out.println("4. Mostrar inventario");
            System.out.println("5. Salir");
            System.out.print("Ingrese una opción: ");

            try {
                opcion = scanner.nextInt();
                scanner.nextLine(); // Consumir la nueva línea

                switch (opcion) {
                    case 1:
                        // Lógica para agregar producto
                        break;
                    case 2:
                        // Lógica para eliminar producto
                        break;
                    case 3:
                        // Lógica para buscar producto
                        break;
                    case 4:
                        // Lógica para mostrar inventario
                        break;
                    case 5:
                        System.out.println("Saliendo del sistema...");
                        break;
                    default:
                        System.out.println("Opción inválida.");
                }
            } catch (java.util.InputMismatchException e) {
                System.out.println("Error: Ingrese un número entero.");
                scanner.nextLine(); // Limpiar el buffer del scanner
                opcion = 0; // Para que el bucle continúe
            }
        } while (opcion != 5);

        scanner.close();
    }

    
}
